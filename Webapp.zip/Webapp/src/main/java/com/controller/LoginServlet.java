package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capg.First;
import com.modal.MyPojo;
import com.service.ValidateImp;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ValidateImp loginService= new ValidateImp(); 
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("userName");
		String userPwd= request.getParameter("userPwd");
		MyPojo obj =new MyPojo(userName,userPwd);
		if(loginService.isValidLogin(obj))
		{
			response.sendRedirect("Pages/Sucess.html");
		}
		else 
		{
			response.sendRedirect("index.html");
		}
		// TODO Auto-generated method stub
	}

}
