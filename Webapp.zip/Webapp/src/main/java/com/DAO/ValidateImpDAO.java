package com.DAO;

import java.util.List;

import javax.persistence.*;

import com.modal.MyPojo;

public class ValidateImpDAO implements IValidateDAO{

	public boolean isValidLogin(MyPojo obj) {
		EntityManager manager=getEntityManagerFactory().createEntityManager();
		EntityTransaction transaction= manager.getTransaction();
		transaction.begin();
		String sql="from MyPojo lgn where lgn.userName=:uName and lgn.userPwd=:uPwd";
		Query query= manager.createQuery(sql);
		query.setParameter("uName", obj.getUserName());
		query.setParameter("uPwd", obj.getUserPwd());
		
		List<MyPojo> logins= query.getResultList();
		transaction.commit();
		manager.close();
		
		if(logins.size()>0) 
			return true;
		
		return false;
	}
	
	private EntityManagerFactory getEntityManagerFactory() {
		return Persistence.createEntityManagerFactory("jpademo");
	}
	
}
