package com.DAO;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.modal.MyPojo;

public class Entero {
	public static void main(String[] args)
	{
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager = emf.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
			MyPojo obj1=new MyPojo(1,"tom","tom123");
			MyPojo obj2=new MyPojo(2,"jack","jack123");
			entityManager.persist(obj1);
			entityManager.persist(obj2);
		transaction.commit();
		entityManager.close();
	}
}
