package com.DAO;

import com.modal.MyPojo;

public interface IValidateDAO {
	public boolean isValidLogin(MyPojo obj);
}
