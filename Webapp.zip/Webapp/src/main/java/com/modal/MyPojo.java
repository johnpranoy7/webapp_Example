package com.modal;

import javax.persistence.*;

@Entity
@Table(name="UserTable")
public class MyPojo {
	@Id
	private int userId;
	private String userName;
	private String userPwd;
	public static int i=1;
	public MyPojo(int userId,String userName, String userPwd) {
		super();
		this.userId=userId;
		this.userName = userName;
		this.userPwd = userPwd;
	};
	
	public MyPojo(String userName, String userPwd) {
		super();
		this.userId= ++i;
		this.userName = userName;
		this.userPwd = userPwd;
	};
	public MyPojo()
	{
		
	}
	
	public int getUserid() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPwd() {
		return userPwd;
	}
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}
	
}
