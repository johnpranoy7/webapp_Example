package com.service;

import com.capg.First;
import com.modal.MyPojo;

public interface IValidate {
	boolean isValidLogin(MyPojo obj);
}
