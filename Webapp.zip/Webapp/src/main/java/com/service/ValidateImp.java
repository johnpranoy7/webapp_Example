package com.service;

import com.DAO.ValidateImpDAO;
import com.capg.First;
import com.modal.MyPojo;

public class ValidateImp implements IValidate{
	ValidateImpDAO dao = new ValidateImpDAO();
	@Override
	public boolean isValidLogin(MyPojo obj) {
		return dao.isValidLogin(obj);
		/*if(obj.getUserName().equals("tom") && (obj.getUserPwd().equals("tom123")))
			return true;
		else
			return false;
		*/
	}

}
